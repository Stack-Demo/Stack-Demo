import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.ProductPage;
import utils.TestUtils;
import java.util.List;

/**
 * TC - Product Test Cases (TC-PRD-001 to TC-PRD-035)
 * Sheet: TC - Mohamed Abdelhamed (Product)
 * Site: https://bstackdemo.com
 */
public class TC_PRD_001_To_035_ProductTests extends BaseTest {

    private ProductPage productPage;

    @BeforeMethod(alwaysRun = true)
    public void loginAndNavigate() {
        TestUtils.loginAs(driver, "demouser");
        productPage = new ProductPage(driver);
    }

    // TC-PRD-001
    @Test(description = "TC-PRD-001: Product listing shows exactly 25 products by default")
    public void TC_PRD_001_ProductListingShows25() {
        Assert.assertEquals(productPage.getProductCount(), 25,
            "Should display exactly 25 products with no filters");
    }

    // TC-PRD-002
    @Test(description = "TC-PRD-002: Apple filter returns exactly 9 Apple products")
    public void TC_PRD_002_AppleFilterReturns9() {
        productPage.applyVendorFilter("Apple");
        Assert.assertEquals(productPage.getProductCount(), 9,
            "Apple filter should return exactly 9 products");
        productPage.getProductNamesList().forEach(name ->
            Assert.assertTrue(name.contains("iPhone") || name.contains("Apple"),
                "All products should be Apple. Found: " + name));
    }

    // TC-PRD-003
    @Test(description = "TC-PRD-003: Samsung filter returns exactly 7 Samsung products")
    public void TC_PRD_003_SamsungFilterReturns7() {
        productPage.applyVendorFilter("Samsung");
        Assert.assertEquals(productPage.getProductCount(), 7,
            "Samsung filter should return exactly 7 products");
    }

    // TC-PRD-004
    @Test(description = "TC-PRD-004: Google filter returns exactly 3 Google products")
    public void TC_PRD_004_GoogleFilterReturns3() {
        productPage.applyVendorFilter("Google");
        Assert.assertEquals(productPage.getProductCount(), 3,
            "Google filter should return exactly 3 products");
    }

    // TC-PRD-005
    @Test(description = "TC-PRD-005: OnePlus filter returns exactly 6 OnePlus products")
    public void TC_PRD_005_OnePlusFilterReturns6() {
        productPage.applyVendorFilter("OnePlus");
        Assert.assertEquals(productPage.getProductCount(), 6,
            "OnePlus filter should return exactly 6 products");
    }

    // TC-PRD-006
    @Test(description = "TC-PRD-006: Apple + Samsung filter returns 16 products")
    public void TC_PRD_006_ApplePlusSamsungReturns16() {
        productPage.applyVendorFilter("Apple");
        productPage.applyVendorFilter("Samsung");
        Assert.assertEquals(productPage.getProductCount(), 16,
            "Apple + Samsung combined should return 16 products");
    }

    // TC-PRD-007
    @Test(description = "TC-PRD-007: Unchecking Apple filter restores all 25 products")
    public void TC_PRD_007_UncheckAppleRestores25() {
        productPage.applyVendorFilter("Apple");
        Assert.assertEquals(productPage.getProductCount(), 9);
        productPage.applyVendorFilter("Apple"); // uncheck
        Assert.assertEquals(productPage.getProductCount(), 25,
            "Removing Apple filter should restore all 25 products");
    }

    // TC-PRD-008
    @Test(description = "TC-PRD-008: Sort Lowest to Highest orders products by ascending price")
    public void TC_PRD_008_SortLowestToHighest() {
        productPage.selectSort("Lowest to Highest");
        List<Double> prices = productPage.getProductPricesList();
        for (int i = 0; i < prices.size() - 1; i++) {
            Assert.assertTrue(prices.get(i) <= prices.get(i + 1),
                "Prices should be in ascending order at index " + i);
        }
        Assert.assertEquals(prices.get(0), 399.0, "Cheapest product (Pixel 2) should be first at $399");
    }

    // TC-PRD-009
    @Test(description = "TC-PRD-009: Sort Highest to Lowest orders products by descending price")
    public void TC_PRD_009_SortHighestToLowest() {
        productPage.selectSort("Highest to Lowest");
        List<Double> prices = productPage.getProductPricesList();
        for (int i = 0; i < prices.size() - 1; i++) {
            Assert.assertTrue(prices.get(i) >= prices.get(i + 1),
                "Prices should be in descending order at index " + i);
        }
        Assert.assertEquals(prices.get(0), 1399.0, "Galaxy S20 Ultra ($1399) should be first");
    }

    // TC-PRD-010
    @Test(description = "TC-PRD-010: Default sort shows products in original API order")
    public void TC_PRD_010_DefaultSortOrder() {
        List<String> names = productPage.getProductNamesList();
        Assert.assertEquals(names.get(0), "iPhone 12", "First product should be iPhone 12 by default");
    }

    // TC-PRD-011
    @Test(description = "TC-PRD-011: Apple filter + Lowest to Highest sort shows 9 Apple in ascending price")
    public void TC_PRD_011_AppleFilterPlusLowestToHighest() {
        productPage.applyVendorFilter("Apple");
        productPage.selectSort("Lowest to Highest");
        Assert.assertEquals(productPage.getProductCount(), 9);
        List<Double> prices = productPage.getProductPricesList();
        for (int i = 0; i < prices.size() - 1; i++) {
            Assert.assertTrue(prices.get(i) <= prices.get(i + 1));
        }
        Assert.assertEquals(prices.get(0), 499.0, "iPhone XR ($499) should be cheapest Apple product");
    }

    // TC-PRD-012
    @Test(description = "TC-PRD-012: Samsung filter + Highest to Lowest shows Galaxy S20 Ultra first")
    public void TC_PRD_012_SamsungFilterPlusHighestToLowest() {
        productPage.applyVendorFilter("Samsung");
        productPage.selectSort("Highest to Lowest");
        Assert.assertEquals(productPage.getProductCount(), 7);
        List<String> names = productPage.getProductNamesList();
        Assert.assertEquals(names.get(0), "Galaxy S20 Ultra",
            "Galaxy S20 Ultra ($1399) should be first after Samsung + desc sort");
    }

    // TC-PRD-013
    @Test(description = "TC-PRD-013: iPhone 12 shows correct price of $799")
    public void TC_PRD_013_IPhone12Price799() {
        String price = productPage.getProductPriceByName("iPhone 12");
        Assert.assertEquals(price, "799", "iPhone 12 price should be $799");
    }

    // TC-PRD-014
    @Test(description = "TC-PRD-014: Galaxy S20 Ultra shows correct price of $1399")
    public void TC_PRD_014_GalaxyS20UltraPrice1399() {
        String price = productPage.getProductPriceByName("Galaxy S20 Ultra");
        Assert.assertEquals(price, "1399", "Galaxy S20 Ultra price should be $1399");
    }

    // TC-PRD-015
    @Test(description = "TC-PRD-015: One Plus 6T shows correct price of $429")
    public void TC_PRD_015_OnePlus6TPrice429() {
        String price = productPage.getProductPriceByName("One Plus 6T");
        Assert.assertEquals(price, "429", "One Plus 6T price should be $429");
    }

    // TC-PRD-016
    @Test(description = "TC-PRD-016: Clicking iPhone 12 card navigates to correct detail page")
    public void TC_PRD_016_ClickIPhone12OpensDetail() {
        productPage.clickProductByName("iPhone 12");
        Assert.assertTrue(driver.getCurrentUrl().contains("/product/"),
            "URL should contain /product/ after clicking iPhone 12");
        Assert.assertTrue(driver.getPageSource().contains("iPhone 12"),
            "Detail page should show iPhone 12");
        Assert.assertTrue(driver.getPageSource().contains("799"),
            "Detail page should show price $799");
    }

    // TC-PRD-017
    @Test(description = "TC-PRD-017: Clicking Galaxy S20 Ultra opens correct detail page")
    public void TC_PRD_017_ClickGalaxyS20UltraOpensDetail() {
        productPage.clickProductByName("Galaxy S20 Ultra");
        Assert.assertTrue(driver.getPageSource().contains("Galaxy S20 Ultra"));
        Assert.assertTrue(driver.getPageSource().contains("1399"));
    }

    // TC-PRD-018
    @Test(description = "TC-PRD-018: Clicking Pixel 2 card opens correct detail page")
    public void TC_PRD_018_ClickPixel2OpensDetail() {
        productPage.clickProductByName("Pixel 2");
        Assert.assertTrue(driver.getPageSource().contains("Pixel 2"));
        Assert.assertTrue(driver.getPageSource().contains("399"));
    }

    // TC-PRD-019
    @Test(description = "TC-PRD-019: Product detail page has 'Add to cart' button")
    public void TC_PRD_019_DetailPageHasAddToCartButton() {
        productPage.clickProductByName("iPhone 11");
        WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector("[class*='buy-btn'], [class*='add-to-cart']")));
        Assert.assertTrue(btn.isDisplayed(), "'Add to cart' button should be visible on detail page");
    }

    // TC-PRD-020
    @Test(description = "TC-PRD-020: Detail page price matches listing price for Galaxy Note 20")
    public void TC_PRD_020_DetailPriceMatchesListing() {
        String listingPrice = productPage.getProductPriceByName("Galaxy Note 20");
        productPage.clickProductByName("Galaxy Note 20");
        Assert.assertTrue(driver.getPageSource().contains(listingPrice),
            "Detail page price should match listing price (" + listingPrice + ") for Galaxy Note 20");
    }

    // TC-PRD-021
    @Test(description = "TC-PRD-021: All 25 product images load for demouser")
    public void TC_PRD_021_ProductImagesLoadForDemouser() {
        Assert.assertTrue(productPage.areProductImagesLoaded(),
            "All product images should load for demouser");
    }

    // TC-PRD-022
    @Test(description = "TC-PRD-022: All product images are broken for image_not_loading_user")
    public void TC_PRD_022_ProductImagesBrokenForImageNotLoadingUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage_Helper helper = new LoginPage_Helper(driver);
        helper.login("image_not_loading_user", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        productPage = new ProductPage(driver);
        Assert.assertTrue(productPage.areProductImagesBroken(),
            "All images should be broken for image_not_loading_user");
    }

    // TC-PRD-023
    @Test(description = "TC-PRD-023: Vendor filter panel shows all 4 vendor groups")
    public void TC_PRD_023_FilterPanelShowsAllVendors() {
        List<String> vendors = productPage.getVendorFilterNames();
        Assert.assertTrue(vendors.stream().anyMatch(v -> v.equalsIgnoreCase("Apple")));
        Assert.assertTrue(vendors.stream().anyMatch(v -> v.equalsIgnoreCase("Samsung")));
        Assert.assertTrue(vendors.stream().anyMatch(v -> v.equalsIgnoreCase("Google")));
        Assert.assertTrue(vendors.stream().anyMatch(v -> v.equalsIgnoreCase("OnePlus")));
    }

    // TC-PRD-024
    @Test(description = "TC-PRD-024: Filter checkbox retains checked state after scroll")
    public void TC_PRD_024_FilterRetainsStateAfterScroll() {
        productPage.applyVendorFilter("Samsung");
        ((org.openqa.selenium.JavascriptExecutor) driver)
            .executeScript("window.scrollTo(0, document.body.scrollHeight)");
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}
        ((org.openqa.selenium.JavascriptExecutor) driver)
            .executeScript("window.scrollTo(0, 0)");
        Assert.assertEquals(productPage.getProductCount(), 7,
            "Samsung filter should still be active after scroll");
    }

    // TC-PRD-025
    @Test(description = "TC-PRD-025: Each product card has 'Add to cart' button")
    public void TC_PRD_025_ProductCardHasAddToCartButton() {
        String[] products = {"iPhone 12", "Galaxy S9", "One Plus 8"};
        for (String p : products) {
            String label = productPage.getButtonLabelByProductName(p);
            Assert.assertFalse(label.isEmpty(), "Add to cart button should be present for " + p);
        }
    }

    // TC-PRD-026
    @Test(description = "TC-PRD-026: fav_user sees favourite icons on product cards")
    public void TC_PRD_026_FavUserSeesHeartIcons() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage_Helper helper = new LoginPage_Helper(driver);
        helper.login("fav_user", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        productPage = new ProductPage(driver);
        Assert.assertTrue(productPage.hasFavouriteIcons(),
            "fav_user should see filled heart icons on product cards");
    }

    // TC-PRD-027
    @Test(description = "TC-PRD-027: Sort persists when navigating back from product detail")
    public void TC_PRD_027_SortPersistsOnBackNavigation() {
        productPage.selectSort("Highest to Lowest");
        productPage.clickProductByName("Galaxy S20 Ultra");
        driver.navigate().back();
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        List<Double> prices = productPage.getProductPricesList();
        Assert.assertEquals(prices.get(0), 1399.0,
            "After Back, sort should still be Highest to Lowest (Galaxy S20 Ultra first)");
    }

    // TC-PRD-028
    @Test(description = "TC-PRD-028: Filter state persists when navigating back from product detail")
    public void TC_PRD_028_FilterPersistsOnBackNavigation() {
        productPage.applyVendorFilter("Apple");
        Assert.assertEquals(productPage.getProductCount(), 9);
        productPage.clickProductByName("iPhone 12");
        driver.navigate().back();
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        Assert.assertEquals(productPage.getProductCount(), 9,
            "Apple filter should remain active after Back navigation");
    }

    // TC-PRD-029
    @Test(description = "TC-PRD-029: iPhone 12 ($799) is neither cheapest nor most expensive")
    public void TC_PRD_029_IPhone12PriceBoundaryVerification() {
        productPage.selectSort("Lowest to Highest");
        List<Double> prices = productPage.getProductPricesList();
        Assert.assertEquals(prices.get(0), 399.0, "Pixel 2 ($399) should be cheapest");
        Assert.assertEquals(prices.get(prices.size() - 1), 1399.0, "Galaxy S20 Ultra ($1399) should be priciest");
        Assert.assertTrue(prices.contains(799.0), "iPhone 12 at $799 should appear in middle range");
    }

    // TC-PRD-030
    @Test(description = "TC-PRD-030: Pixel 4 detail page shows only Pixel 4 data")
    public void TC_PRD_030_ProductDetailNoOtherVendors() {
        productPage.clickProductByName("Pixel 4");
        String src = driver.getPageSource();
        Assert.assertTrue(src.contains("Pixel 4"), "Should show Pixel 4");
        Assert.assertFalse(src.contains("Galaxy S20") || src.contains("iPhone 12"),
            "Detail page should not show other vendors' products");
    }

    // TC-PRD-031
    @Test(description = "TC-PRD-031: One Plus 6T is cheapest OnePlus product")
    public void TC_PRD_031_OnePlus6TCheapestOnePlus() {
        productPage.applyVendorFilter("OnePlus");
        productPage.selectSort("Lowest to Highest");
        List<String> names = productPage.getProductNamesList();
        Assert.assertEquals(names.get(0), "One Plus 6T",
            "One Plus 6T ($429) should be cheapest OnePlus product");
    }

    // TC-PRD-032
    @Test(description = "TC-PRD-032: Galaxy S20 Ultra is most expensive Samsung product")
    public void TC_PRD_032_GalaxyS20UltraMostExpensiveSamsung() {
        productPage.applyVendorFilter("Samsung");
        productPage.selectSort("Highest to Lowest");
        List<String> names = productPage.getProductNamesList();
        Assert.assertEquals(names.get(0), "Galaxy S20 Ultra",
            "Galaxy S20 Ultra should be most expensive Samsung product");
    }

    // TC-PRD-033
    @Test(description = "TC-PRD-033: Product listing accessible without login")
    public void TC_PRD_033_ProductListingAccessibleWithoutLogin() {
        driver.manage().deleteAllCookies();
        driver.get(TestUtils.BASE_URL + "/");
        int count = driver.findElements(By.cssSelector(".shelf-item")).size();
        Assert.assertTrue(count > 0,
            "Product listing should be visible to unauthenticated users");
    }

    // TC-PRD-034
    @Test(description = "TC-PRD-034: Add to cart without login redirects to sign-in")
    public void TC_PRD_034_AddToCartUnauthenticatedRedirects() {
        driver.manage().deleteAllCookies();
        driver.get(TestUtils.BASE_URL + "/");
        productPage = new ProductPage(driver);
        productPage.addToCartByName("iPhone 12");
        wait.until(ExpectedConditions.urlContains("/signin"));
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"),
            "Unauthenticated add-to-cart should redirect to /signin");
    }

    // TC-PRD-035
    @Test(description = "TC-PRD-035: Vendor filter count badges match actual product counts")
    public void TC_PRD_035_VendorFilterCountBadgesCorrect() {
        // Apple = 9, Samsung = 7, Google = 3, OnePlus = 6 — verify by filtering each
        String[][] vendorCounts = {{"Apple", "9"}, {"Samsung", "7"}, {"Google", "3"}, {"OnePlus", "6"}};
        for (String[] vc : vendorCounts) {
            String vendor = vc[0]; int expected = Integer.parseInt(vc[1]);
            productPage.applyVendorFilter(vendor);
            int actual = productPage.getProductCount();
            Assert.assertEquals(actual, expected,
                vendor + " filter should return " + expected + " products, got " + actual);
            productPage.applyVendorFilter(vendor); // uncheck
        }
    }

    // Inner helper (avoids circular import)
    private static class LoginPage_Helper {
        private WebDriver driver;
        LoginPage_Helper(org.openqa.selenium.WebDriver d) { this.driver = d; }
        void login(String user, String pass) {
            new pages.LoginPage(driver).login(user, pass);
        }
    }
}
