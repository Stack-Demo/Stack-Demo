import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import utils.TestUtils;

/**
 * TC - Login Test Cases (TC-LGN-001 to TC-LGN-018)
 * Sheet: TC - Mohamed Gamal (Login)
 * Site: https://bstackdemo.com
 */
public class TC_LGN_001_To_018_LoginTests extends BaseTest {

    // ─────────────────────────────────────────────
    // TC-LGN-001: Successful Login with demouser
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-001: demouser can sign in and is redirected to homepage")
    public void TC_LGN_001_SuccessfulLoginDemouser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("demouser", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        Assert.assertEquals(driver.getCurrentUrl(), TestUtils.BASE_URL + "/");
        Assert.assertTrue(driver.findElements(By.cssSelector(".shelf-item")).size() > 0,
            "Product listing grid should be visible after login");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-002: Successful Login with existing_orders_user
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-002: existing_orders_user can log in and see order history")
    public void TC_LGN_002_SuccessfulLoginExistingOrdersUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("existing_orders_user", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        driver.get(TestUtils.BASE_URL + "/orders");
        wait.until(ExpectedConditions.urlContains("/orders"));
        int orders = driver.findElements(By.cssSelector(".order-item, .order-row, [class*='order']")).size();
        Assert.assertTrue(orders >= 5, "Orders page should contain at least 5 seeded orders");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-003: Successful Login with fav_user
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-003: fav_user logs in and product listing shows favourite heart icons")
    public void TC_LGN_003_SuccessfulLoginFavUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("fav_user", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        boolean favIconsPresent = driver.findElements(
            By.cssSelector(".shelf-item__heart, [class*='fav'], [class*='heart']")).size() > 0;
        Assert.assertTrue(favIconsPresent, "Favourite heart icons should be visible for fav_user");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-004: Login Blocked for locked_user
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-004: locked_user cannot login and sees locked account error")
    public void TC_LGN_004_LoginBlockedForLockedUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("locked_user", "testingisfun99");
        String errorMsg = loginPage.getErrorMessage();
        Assert.assertTrue(errorMsg.toLowerCase().contains("locked"),
            "Error message should mention account is locked. Got: " + errorMsg);
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"),
            "User should remain on sign-in page");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-005: image_not_loading_user logs in with broken images
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-005: image_not_loading_user logs in but all product images are broken")
    public void TC_LGN_005_LoginImageNotLoadingUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login("image_not_loading_user", "testingisfun99");
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        var imgs = driver.findElements(By.cssSelector(".shelf-item__thumb img"));
        Assert.assertFalse(imgs.isEmpty(), "Product cards should be present");
        long brokenCount = imgs.stream().filter(img -> {
            Object result = ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript("return arguments[0].complete && arguments[0].naturalWidth > 0", img);
            return !(Boolean) result;
        }).count();
        Assert.assertEquals(brokenCount, imgs.size(), "All product images should be broken for this user");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-006: Sign In with No Credentials
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-006: Clicking Sign In without credentials should show validation message")
    public void TC_LGN_006_SignInWithNoCredentials() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.clickSignIn();
        boolean validationShown = loginPage.isErrorDisplayed() ||
            !driver.findElements(By.cssSelector("[class*='error'], [class*='alert']")).isEmpty();
        Assert.assertTrue(validationShown, "Validation message should appear when no credentials selected");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-007: Sign In with Only Username
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-007: Sign In with username only should show password validation message")
    public void TC_LGN_007_SignInOnlyUsername() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.selectUsername("demouser");
        loginPage.clickSignIn();
        boolean errorShown = loginPage.isErrorDisplayed() ||
            !driver.findElements(By.cssSelector("[class*='error'], [class*='alert']")).isEmpty();
        Assert.assertTrue(errorShown, "Validation error should appear when password is not selected");
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"), "Should remain on signin page");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-008: Sign In with Only Password
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-008: Sign In with password only should show username validation message")
    public void TC_LGN_008_SignInOnlyPassword() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        loginPage.selectPassword("testingisfun99");
        loginPage.clickSignIn();
        boolean errorShown = loginPage.isErrorDisplayed() ||
            !driver.findElements(By.cssSelector("[class*='error'], [class*='alert']")).isEmpty();
        Assert.assertTrue(errorShown, "Validation error should appear when username is not selected");
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"), "Should remain on signin page");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-009: Username Dropdown Lists All 5 Users
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-009: Username dropdown should have exactly 5 user options")
    public void TC_LGN_009_UsernameDropdownFiveOptions() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        int count = loginPage.getUsernameOptionsCount();
        Assert.assertEquals(count, 5, "Username dropdown should have exactly 5 options");
        Assert.assertTrue(loginPage.usernameOptionExists("demouser"));
        Assert.assertTrue(loginPage.usernameOptionExists("locked_user"));
        Assert.assertTrue(loginPage.usernameOptionExists("image_not_loading_user"));
        Assert.assertTrue(loginPage.usernameOptionExists("existing_orders_user"));
        Assert.assertTrue(loginPage.usernameOptionExists("fav_user"));
    }

    // ─────────────────────────────────────────────
    // TC-LGN-010: Password Dropdown Has Correct Option
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-010: Password dropdown should contain 'testingisfun99'")
    public void TC_LGN_010_PasswordDropdownContainsCorrectOption() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        Assert.assertTrue(loginPage.passwordOptionExists("testingisfun99"),
            "Password dropdown should contain 'testingisfun99'");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-011: Session Persists After Page Refresh
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-011: Session is maintained after browser refresh")
    public void TC_LGN_011_SessionPersistsAfterRefresh() {
        TestUtils.loginAs(driver, "demouser");
        driver.navigate().refresh();
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        Assert.assertEquals(driver.getCurrentUrl(), TestUtils.BASE_URL + "/",
            "User should remain on homepage after refresh, not redirected to signin");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-012: Logout Redirects to Sign-In
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-012: Logout clears session and redirects to /signin")
    public void TC_LGN_012_LogoutRedirectsToSignIn() {
        TestUtils.loginAs(driver, "demouser");
        driver.findElement(By.cssSelector(".user-icon, [class*='user'], [class*='account']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("[class*='logout'], [class*='sign-out'], [class*='signout']"))).click();
        wait.until(ExpectedConditions.urlContains("/signin"));
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"),
            "Should redirect to /signin after logout");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-013: /orders Not Accessible After Logout
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-013: Accessing /orders after logout should redirect to sign-in")
    public void TC_LGN_013_OrdersNotAccessibleAfterLogout() {
        TestUtils.loginAs(driver, "demouser");
        driver.findElement(By.cssSelector(".user-icon, [class*='user']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("[class*='logout'], [class*='signout']"))).click();
        wait.until(ExpectedConditions.urlContains("/signin"));
        driver.get(TestUtils.BASE_URL + "/orders");
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"),
            "Navigating to /orders after logout should redirect to /signin");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-014: Back Button After Logout Does Not Restore Session
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-014: Browser Back after logout should not restore authenticated session")
    public void TC_LGN_014_BackButtonAfterLogout() {
        TestUtils.loginAs(driver, "demouser");
        driver.findElement(By.cssSelector(".user-icon, [class*='user']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("[class*='logout'], [class*='signout']"))).click();
        wait.until(ExpectedConditions.urlContains("/signin"));
        driver.navigate().back();
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        Assert.assertTrue(driver.getCurrentUrl().contains("/signin"),
            "Back button after logout should not restore session");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-015: Sign-In Page Elements Visible
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-015: All sign-in page elements are visible with correct labels")
    public void TC_LGN_015_SignInPageElementsVisible() {
        driver.get(TestUtils.SIGNIN_URL);
        Assert.assertTrue(driver.findElement(By.cssSelector("img[alt*='BrowserStack'], img[alt*='logo'], .logo img")).isDisplayed(),
            "BrowserStack logo should be visible");
        Assert.assertTrue(driver.findElement(By.id("react-select-2-container")).isDisplayed(),
            "Username dropdown should be visible");
        Assert.assertTrue(driver.findElement(By.id("react-select-3-container")).isDisplayed(),
            "Password dropdown should be visible");
        Assert.assertTrue(driver.findElement(By.id("login-btn")).isDisplayed(),
            "Sign In button should be visible");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-016: Sign-In Page Title is Correct
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-016: Browser tab title should identify the sign-in page")
    public void TC_LGN_016_SignInPageTitleCorrect() {
        driver.get(TestUtils.SIGNIN_URL);
        String title = driver.getTitle();
        Assert.assertTrue(title.toLowerCase().contains("stackdemo") || title.toLowerCase().contains("browserstack"),
            "Page title should contain 'StackDemo' or 'BrowserStack'. Got: " + title);
    }

    // ─────────────────────────────────────────────
    // TC-LGN-017: Sign-In Page Responsive on 375×667
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-017: Sign-in page renders correctly on 375x667 mobile viewport")
    public void TC_LGN_017_SignInPageResponsiveMobile() {
        TestUtils.setMobileViewport(driver);
        driver.get(TestUtils.SIGNIN_URL);
        WebElement signInBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-btn")));
        Assert.assertTrue(signInBtn.isDisplayed(), "Sign In button should be visible on mobile");
        Assert.assertTrue(driver.findElement(By.id("react-select-2-container")).isDisplayed(),
            "Username dropdown should be visible on mobile");
        // Check no horizontal overflow
        Long scrollWidth = (Long) ((org.openqa.selenium.JavascriptExecutor) driver)
            .executeScript("return document.body.scrollWidth");
        Long clientWidth = (Long) ((org.openqa.selenium.JavascriptExecutor) driver)
            .executeScript("return document.body.clientWidth");
        Assert.assertFalse(scrollWidth > clientWidth,
            "No horizontal overflow should occur at mobile 375px viewport");
    }

    // ─────────────────────────────────────────────
    // TC-LGN-018: Regression – Failed Login Then Successful
    // ─────────────────────────────────────────────
    @Test(description = "TC-LGN-018: After locked_user error, switching to demouser succeeds")
    public void TC_LGN_018_RegressionLoginAfterLockedUser() {
        driver.get(TestUtils.SIGNIN_URL);
        LoginPage loginPage = new LoginPage(driver);
        // Attempt 1: locked_user
        loginPage.login("locked_user", "testingisfun99");
        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error should appear for locked_user");
        // Attempt 2: switch to demouser
        loginPage.selectUsername("demouser");
        loginPage.clickSignIn();
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        Assert.assertEquals(driver.getCurrentUrl(), TestUtils.BASE_URL + "/",
            "Login with demouser should succeed after locked_user attempt");
    }
}
