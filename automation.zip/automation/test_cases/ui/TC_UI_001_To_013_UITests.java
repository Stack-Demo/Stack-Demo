import base.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.CartPage;
import pages.ProductPage;
import utils.TestUtils;

/**
 * TC - UI / Responsive Test Cases (TC-UI-001 to TC-UI-013)
 * Sheet: TC - Mohamed Mamdouh (UI)
 * Site: https://bstackdemo.com
 */
public class TC_UI_001_To_013_UITests extends BaseTest {

    private ProductPage productPage;
    private CartPage    cartPage;

    @BeforeMethod(alwaysRun = true)
    public void prepare() {
        TestUtils.loginAs(driver, "demouser");
        productPage = new ProductPage(driver);
        cartPage    = new CartPage(driver);
    }

    // TC-UI-001
    @Test(description = "TC-UI-001: Homepage product grid layout on 1920×1080 desktop")
    public void TC_UI_001_ProductGridLayout1920x1080() {
        TestUtils.setFullHDViewport(driver);
        driver.navigate().refresh();
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".shelf-item")));
        Assert.assertEquals(productPage.getProductCount(), 25,
            "All 25 product cards should be visible at 1920x1080");
        Assert.assertTrue(driver.findElement(By.cssSelector(".filters")).isDisplayed(),
            "Filter sidebar should be visible");
        Long scrollWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.scrollWidth");
        Long clientWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.clientWidth");
        Assert.assertFalse(scrollWidth > clientWidth,
            "No horizontal overflow at 1920x1080");
    }

    // TC-UI-002
    @Test(description = "TC-UI-002: Product listing collapses to single column on 375×667 mobile")
    public void TC_UI_002_ProductListingMobileSingleColumn() {
        TestUtils.setMobileViewport(driver);
        driver.navigate().refresh();
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".shelf-item")));
        Long scrollWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.scrollWidth");
        Long clientWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.clientWidth");
        Assert.assertFalse(scrollWidth > clientWidth + 5,
            "No horizontal overflow on 375px mobile viewport");
    }

    // TC-UI-003
    @Test(description = "TC-UI-003: Filter sidebar hidden or collapsed by default on mobile 375×667")
    public void TC_UI_003_FilterSidebarHiddenOnMobile() {
        TestUtils.setMobileViewport(driver);
        driver.navigate().refresh();
        boolean filterVisible;
        try {
            WebElement filter = driver.findElement(By.cssSelector(".filters"));
            filterVisible = filter.isDisplayed() &&
                filter.getRect().getWidth() > 0;
        } catch (Exception e) {
            filterVisible = false;
        }
        Assert.assertFalse(filterVisible,
            "Filter sidebar should be hidden or collapsed on 375px mobile viewport");
    }

    // TC-UI-004
    @Test(description = "TC-UI-004: Cart icon and badge visible on all key pages with 1 item in cart")
    public void TC_UI_004_CartIconVisibleAllPages() {
        productPage.addToCartByName("iPhone 11");
        String[] pages = {"/", "/product/1", "/cart", "/checkout"};
        for (String path : pages) {
            driver.get(TestUtils.BASE_URL + path);
            try {
                WebElement badge = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector(".cart-icon, [class*='cart']")));
                Assert.assertTrue(badge.isDisplayed(),
                    "Cart icon should be visible on page: " + path);
            } catch (Exception e) {
                Assert.fail("Cart icon not found on page: " + path);
            }
        }
    }

    // TC-UI-005
    @Test(description = "TC-UI-005: BrowserStack logo click navigates to homepage from any page")
    public void TC_UI_005_LogoClickNavigatesToHomepage() {
        productPage.clickProductByName("Pixel 4");
        Assert.assertTrue(driver.getCurrentUrl().contains("/product/"),
            "Should be on a product detail page");
        WebElement logo = wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("a img[alt*='BrowserStack'], .logo a, header a:first-child")));
        logo.click();
        wait.until(ExpectedConditions.urlToBe(TestUtils.BASE_URL + "/"));
        Assert.assertEquals(driver.getCurrentUrl(), TestUtils.BASE_URL + "/",
            "Logo click should navigate to homepage");
    }

    // TC-UI-006
    @Test(description = "TC-UI-006: Product card shows visual feedback on hover")
    public void TC_UI_006_ProductCardHoverState() {
        WebElement card = wait.until(ExpectedConditions.visibilityOfElementLocated(
            By.cssSelector(".shelf-item")));
        String styleBefore = card.getCssValue("box-shadow");
        new Actions(driver).moveToElement(card).perform();
        try { Thread.sleep(400); } catch (InterruptedException ignored) {}
        String styleAfter = card.getCssValue("box-shadow");
        // cursor should be pointer or box-shadow should change — visual test
        String cursor = card.getCssValue("cursor");
        Assert.assertTrue(!styleAfter.equals(styleBefore) || cursor.contains("pointer"),
            "Product card should show visual feedback on hover (shadow change or pointer cursor)");
    }

    // TC-UI-007
    @Test(description = "TC-UI-007: Sign In button has visible hover state")
    public void TC_UI_007_SignInButtonHoverState() {
        driver.get(TestUtils.SIGNIN_URL);
        WebElement btn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("login-btn")));
        String bgBefore = btn.getCssValue("background-color");
        new Actions(driver).moveToElement(btn).perform();
        try { Thread.sleep(300); } catch (InterruptedException ignored) {}
        String bgAfter = btn.getCssValue("background-color");
        // Just confirm the button is interactive and visible
        Assert.assertTrue(btn.isDisplayed(), "Sign In button should be visible");
        // Note: exact hover color assertion requires visual testing tools
    }

    // TC-UI-008
    @Test(description = "TC-UI-008: Product listing page title in browser tab is not blank")
    public void TC_UI_008_ProductListingPageTitle() {
        String title = driver.getTitle();
        Assert.assertFalse(title == null || title.isEmpty(),
            "Browser tab title should not be blank or null");
        Assert.assertTrue(title.toLowerCase().contains("stackdemo") ||
            title.toLowerCase().contains("browserstack"),
            "Page title should contain 'StackDemo' or 'BrowserStack'. Got: " + title);
    }

    // TC-UI-009
    @Test(description = "TC-UI-009: Invalid URL returns 404 page without crashing the app")
    public void TC_UI_009_InvalidURL404NoCrash() {
        driver.get(TestUtils.BASE_URL + "/nonexistent-path-xyz");
        String src = driver.getPageSource().toLowerCase();
        boolean handled = src.contains("404") || src.contains("not found") ||
            src.contains("page") || !src.equals("");
        Assert.assertTrue(handled,
            "App should handle invalid URL gracefully — no blank screen or JS crash");
        // Should not be a completely blank page
        Assert.assertFalse(driver.getPageSource().trim().isEmpty(),
            "Page should not be completely blank for invalid URL");
    }

    // TC-UI-010
    @Test(description = "TC-UI-010: Checkout form responsive on iPad 768×1024 viewport")
    public void TC_UI_010_CheckoutFormResponsiveTablet() {
        TestUtils.setTabletViewport(driver);
        productPage.addToCartByName("Galaxy S9");
        driver.findElement(By.cssSelector(".cart-icon, [class*='cart']")).click();
        wait.until(ExpectedConditions.urlContains("/cart"));
        driver.findElement(By.cssSelector(".buy-btn, [class*='checkout']")).click();
        wait.until(ExpectedConditions.urlContains("/checkout"));
        Assert.assertTrue(driver.findElement(By.id("firstNameInput")).isDisplayed(),
            "First name field should be visible on 768x1024 tablet");
        Assert.assertTrue(driver.findElement(By.id("checkout-shipping-continue")).isDisplayed(),
            "Submit button should be accessible on tablet");
    }

    // TC-UI-011
    @Test(description = "TC-UI-011: Product card images display at consistent proportions")
    public void TC_UI_011_ProductCardImagesConsistentProportions() {
        java.util.List<WebElement> imgs = driver.findElements(
            By.cssSelector(".shelf-item__thumb img"));
        Assert.assertFalse(imgs.isEmpty(), "Product images should be present");
        int referenceWidth = imgs.get(0).getSize().getWidth();
        int referenceHeight = imgs.get(0).getSize().getHeight();
        for (WebElement img : imgs) {
            int w = img.getSize().getWidth();
            int h = img.getSize().getHeight();
            Assert.assertEquals(w, referenceWidth,
                "All product images should have the same width");
            Assert.assertEquals(h, referenceHeight,
                "All product images should have the same height");
        }
    }

    // TC-UI-012
    @Test(description = "TC-UI-012: Empty cart state message visible on mobile 375×667")
    public void TC_UI_012_EmptyCartMessageMobile() {
        TestUtils.setMobileViewport(driver);
        driver.get(TestUtils.BASE_URL + "/cart");
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
        Long scrollWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.scrollWidth");
        Long clientWidth = (Long) ((JavascriptExecutor) driver)
            .executeScript("return document.body.clientWidth");
        Assert.assertFalse(scrollWidth > clientWidth + 5,
            "No horizontal overflow on empty cart page at 375px mobile");
        // Page should show some content (not completely blank)
        Assert.assertFalse(driver.getPageSource().trim().isEmpty(),
            "Cart page should render content (empty state or otherwise) on mobile");
    }

    // TC-UI-013
    @Test(description = "TC-UI-013: App renders correctly on Safari / macOS (run in Safari for full coverage)")
    public void TC_UI_013_AppRendersOnSafari() {
        // Note: This test exercises layout checks on the current browser.
        // For true Safari/macOS coverage, run in BrowserStack Automate with Safari 17.
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".shelf-item")));
        Assert.assertEquals(productPage.getProductCount(), 25,
            "All 25 product cards should render correctly");
        Assert.assertTrue(driver.findElement(By.cssSelector(".filters")).isDisplayed(),
            "Filter sidebar should render without layout breaks");
        Assert.assertTrue(driver.findElement(By.cssSelector("header")).isDisplayed(),
            "Header should render correctly");
    }
}
