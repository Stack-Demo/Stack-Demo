# 🤖 BStackDemo Automation Suite
**Selenium + TestNG | Java | Maven**
**Site Under Test:** https://bstackdemo.com

---

## 📁 هيكل المشروع — Project Structure

```
automation/
│
├── pom.xml                          ← Maven dependencies (Selenium, TestNG, WebDriverManager)
├── testng.xml                       ← TestNG suite — runs all tests
│
├── src/main/java/
│   ├── base/
│   │   └── BaseTest.java            ← Setup/Teardown مشترك لكل التيستات
│   ├── pages/
│   │   ├── LoginPage.java           ← Page Object لصفحة الـ Sign In
│   │   ├── ProductPage.java         ← Page Object للمنتجات والفلاتر والسورت
│   │   ├── CartPage.java            ← Page Object للكارت والبادج والـ Total
│   │   └── CheckoutPage.java        ← Page Object لفورم الـ Checkout والـ Confirmation
│   └── utils/
│       └── TestUtils.java           ← Helper methods (login, viewport, navigate)
│
├── test_cases/                      ← ✅ Test Case Automation
│   ├── login/
│   │   └── TC_LGN_001_To_018_LoginTests.java      (18 tests)
│   ├── product/
│   │   └── TC_PRD_001_To_035_ProductTests.java    (35 tests)
│   ├── cart/
│   │   └── TC_CRT_001_To_022_CartTests.java       (22 tests)
│   ├── checkout/
│   │   └── TC_CHK_001_To_022_CheckoutTests.java   (22 tests)
│   └── ui/
│       └── TC_UI_001_To_013_UITests.java          (13 tests)
│
└── bug_reports/                     ← 🐛 Bug Report Automation
    ├── login/
    │   └── BUG_LGN_001_To_005_LoginBugTests.java  (5 bugs)
    ├── cart/
    │   └── BUG_CRT_001_To_007_CartBugTests.java   (7 bugs)
    ├── product/
    │   └── BUG_PRD_001_To_009_ProductBugTests.java (9 bugs)
    ├── checkout/
    │   └── BUG_CHK_001_To_007_CheckoutBugTests.java (7 bugs)
    └── ui/
        └── BUG_UI_001_To_005_UIBugTests.java      (5 bugs)
```

---

## 📊 إجمالي التيستات — Total Test Count

| القسم           | الملف                                  | عدد التيستات |
|-----------------|----------------------------------------|--------------|
| TC Login        | TC_LGN_001_To_018_LoginTests.java      | 18           |
| TC Product      | TC_PRD_001_To_035_ProductTests.java    | 35           |
| TC Cart         | TC_CRT_001_To_022_CartTests.java       | 22           |
| TC Checkout     | TC_CHK_001_To_022_CheckoutTests.java   | 22           |
| TC UI           | TC_UI_001_To_013_UITests.java          | 13           |
| BUG Login       | BUG_LGN_001_To_005_LoginBugTests.java  | 5            |
| BUG Cart        | BUG_CRT_001_To_007_CartBugTests.java   | 7            |
| BUG Product     | BUG_PRD_001_To_009_ProductBugTests.java| 9            |
| BUG Checkout    | BUG_CHK_001_To_007_CheckoutBugTests.java| 7           |
| BUG UI          | BUG_UI_001_To_005_UIBugTests.java      | 5            |
| **Total**       |                                        | **143**      |

---

## ⚙️ المتطلبات — Prerequisites

| الأداة        | الإصدار المطلوب |
|---------------|----------------|
| Java JDK      | 11 أو أعلى     |
| Maven         | 3.8+           |
| Google Chrome | أحدث إصدار     |
| IntelliJ IDEA | (مستحسن)       |

> **ChromeDriver** بيتحمل أوتوماتيك عن طريق مكتبة **WebDriverManager** — مش محتاج تنزله يدويًا.

---

## 🚀 طريقة التشغيل — How to Run

### 1. افتح المشروع في IntelliJ
- افتح **IntelliJ IDEA**
- اختار **File → Open** وافتح فولدر `automation/`
- IntelliJ هيتعرف على الـ Maven project أوتوماتيك

### 2. نزّل الـ Dependencies
```bash
mvn dependency:resolve
```

### 3. شغّل كل التيستات
```bash
mvn test
```

### 4. شغّل ملف تيستات معين فقط
```bash
# مثال: Login tests فقط
mvn test -Dtest=TC_LGN_001_To_018_LoginTests

# مثال: Bug reports الـ Cart فقط
mvn test -Dtest=BUG_CRT_001_To_007_CartBugTests
```

### 5. شغّل عن طريق testng.xml مباشرة (في IntelliJ)
- كليك يمين على `testng.xml`
- اختار **Run 'testng.xml'**

---

## 🗂️ شرح الفولدرات — Folders Explained

### `src/main/java/base/BaseTest.java`
الكلاس الأساسي اللي كل تيست بيرث منه.
- بيفتح Chrome أوتوماتيك قبل كل تيست (`@BeforeMethod`)
- بيقفل البراوزر بعد كل تيست (`@AfterMethod`)
- فيه `driver` و `wait` متاحين لكل التيستات
- بيستخدم **WebDriverManager** لتحميل ChromeDriver أوتوماتيك

### `src/main/java/pages/` — Page Object Model (POM)

| الملف              | المسؤولية                                                           |
|--------------------|---------------------------------------------------------------------|
| `LoginPage.java`   | اختيار Username/Password من الـ dropdowns، الضغط على Sign In، قراءة رسائل الخطأ |
| `ProductPage.java` | فلترة المنتجات، السورت، عد الكاردات، الضغط على منتج، قراءة الأسعار |
| `CartPage.java`    | قراءة الـ Badge، فتح الكارت، حذف منتج، قراءة الـ Total، الضغط على Checkout |
| `CheckoutPage.java`| ملء فورم الـ Checkout، الـ Submit، التحقق من صفحة التأكيد والـ Validation |

### `src/main/java/utils/TestUtils.java`
Helper methods مشتركة:
- `loginAs(driver, "demouser")` → بيعمل login بسرعة قبل كل تيست
- `setMobileViewport(driver)` → بيحط viewport 375×667
- `setTabletViewport(driver)` → بيحط viewport 768×1024
- `setFullHDViewport(driver)` → بيحط viewport 1920×1080
- `navigateTo(driver, "/orders")` → بيفتح صفحة معينة

---

## ✅ test_cases/ — شرح ملفات الـ TC

### `TC_LGN_001_To_018_LoginTests.java` — 18 تيست
| ID          | الموضوع                                               |
|-------------|-------------------------------------------------------|
| TC-LGN-001  | Login ناجح بـ demouser والـ redirect للهوم             |
| TC-LGN-002  | Login بـ existing_orders_user وظهور 5 أوردرات          |
| TC-LGN-003  | Login بـ fav_user وظهور أيقونات القلب على المنتجات    |
| TC-LGN-004  | Login بـ locked_user يظهر رسالة خطأ "locked"          |
| TC-LGN-005  | Login بـ image_not_loading_user وكل الصور مكسورة      |
| TC-LGN-006  | الضغط على Sign In بدون credentials → validation       |
| TC-LGN-007  | Username فقط → validation على الـ Password            |
| TC-LGN-008  | Password فقط → validation على الـ Username            |
| TC-LGN-009  | الـ Username dropdown فيه 5 خيارات بالظبط             |
| TC-LGN-010  | الـ Password dropdown فيه 'testingisfun99'             |
| TC-LGN-011  | الـ Session بتفضل بعد Refresh                         |
| TC-LGN-012  | Logout بيرجعك لصفحة الـ Sign In                      |
| TC-LGN-013  | بعد Logout مش قادر تدخل /orders                      |
| TC-LGN-014  | الـ Back button بعد Logout مش بيرجع الـ Session       |
| TC-LGN-015  | عناصر صفحة الـ Sign In موجودة وصح                    |
| TC-LGN-016  | عنوان التاب فيه StackDemo أو BrowserStack             |
| TC-LGN-017  | صفحة الـ Sign In Responsive على موبايل 375×667       |
| TC-LGN-018  | Regression: بعد فشل locked_user، demouser بينجح       |

---

### `TC_PRD_001_To_035_ProductTests.java` — 35 تيست
| ID Range            | الموضوع                                                  |
|---------------------|----------------------------------------------------------|
| TC-PRD-001          | الهوم بيعرض 25 منتج بدون فلاتر                           |
| TC-PRD-002 to 005   | فلتر Apple=9, Samsung=7, Google=3, OnePlus=6             |
| TC-PRD-006 to 007   | فلتر مشترك Apple+Samsung=16، وإلغاء الفلتر يرجع 25      |
| TC-PRD-008 to 010   | السورت (Lowest, Highest, Default)                        |
| TC-PRD-011 to 012   | فلتر + سورت مع بعض                                      |
| TC-PRD-013 to 015   | أسعار: iPhone12=$799, Galaxy S20 Ultra=$1399, OnePlus6T=$429 |
| TC-PRD-016 to 018   | الكليك على كارت المنتج بيفتح صفحة التفاصيل الصح         |
| TC-PRD-019 to 020   | زر "Add to cart" موجود، سعر التفاصيل مطابق للـ Listing  |
| TC-PRD-021 to 022   | صور تتحمل لـ demouser، صور مكسورة لـ image_not_loading |
| TC-PRD-023 to 026   | الفلتر Panel، الـ checkbox بعد scroll، أزرار الكارت     |
| TC-PRD-027 to 028   | الفلتر والسورت بيفضلوا بعد Back Navigation               |
| TC-PRD-029 to 032   | أسعار حدودية، صفحة التفاصيل لا تعرض منتجات تانية       |
| TC-PRD-033 to 034   | Browse بدون login، Add to cart بدون login → redirect     |
| TC-PRD-035          | عدد المنتجات في الفلتر بيتطابق مع العداد                |

---

### `TC_CRT_001_To_022_CartTests.java` — 22 تيست
| ID Range            | الموضوع                                                  |
|---------------------|----------------------------------------------------------|
| TC-CRT-001 to 003   | إضافة منتج من الـ Listing وصفحة التفاصيل، الـ Badge يتحدث |
| TC-CRT-004 to 006   | الكارت بيعرض الاسم والسعر والـ Total الصح               |
| TC-CRT-007 to 008   | حذف منتج، حذف آخر منتج → الكارت فاضي                   |
| TC-CRT-009          | الكارت بيفضل بعد Refresh                                |
| TC-CRT-010 to 011   | الزر يتغير من "Add to cart" لـ "Remove" وبالعكس         |
| TC-CRT-012 to 013   | زر Checkout والأيقونة بيفتحوا الصفحات الصح              |
| TC-CRT-014          | البادج يرجع صفر بعد Checkout ناجح                       |
| TC-CRT-015 to 016   | أغلى منتج (Galaxy S20 Ultra $1399) وأرخص (Pixel2 $399)  |
| TC-CRT-017          | Double click لا يضاعف الـ Item                          |
| TC-CRT-018          | الـ Thumbnail في الكارت صح                              |
| TC-CRT-019          | الـ Total يتحدث فورًا بعد حذف منتج                     |
| TC-CRT-020          | Logout بيمسح الكارت                                    |
| TC-CRT-021          | Back من الكارت يرجع للـ Listing مع الـ Items            |
| TC-CRT-022          | إضافة كل الـ 25 منتج والـ Badge بيبقى 25               |

---

### `TC_CHK_001_To_022_CheckoutTests.java` — 22 تيست
| ID Range            | الموضوع                                                  |
|---------------------|----------------------------------------------------------|
| TC-CHK-001          | الـ Checkout Page بتتفتح من الكارت                      |
| TC-CHK-002          | Checkout ناجح → صفحة التأكيد تظهر                      |
| TC-CHK-003 to 007   | كل حقل مطلوب (First Name, Last Name, Address, State, Zip) |
| TC-CHK-008 to 010   | Zip Code Validation: صح=10001، غلط=ABCDE أو 1234        |
| TC-CHK-011 to 012   | Order Summary يعرض المنتج والـ Total الصح               |
| TC-CHK-013          | الـ Checkout مش متاح لو الكارت فاضي                    |
| TC-CHK-014 to 015   | صفحة التأكيد تظهر وتحتوي على تفاصيل المنتج             |
| TC-CHK-016          | Back من الـ Checkout يرجع للكارت مع الـ Items           |
| TC-CHK-017          | الـ State Dropdown فيه States أمريكية صح                |
| TC-CHK-018          | الـ First Name بيقبل أسماء عربية/إنجليزية عادية         |
| TC-CHK-019          | مش Authenticated → redirect لـ /signin                 |
| TC-CHK-020          | الـ Checkout Form Responsive على موبايل                 |
| TC-CHK-021          | Validation بيشتغل على Firefox                           |
| TC-CHK-022          | Back من صفحة التأكيد لا يعيد إرسال الأوردر             |

---

### `TC_UI_001_To_013_UITests.java` — 13 تيست
| ID         | الموضوع                                                        |
|------------|----------------------------------------------------------------|
| TC-UI-001  | Layout صح على 1920×1080                                        |
| TC-UI-002  | Single Column على موبايل 375×667                               |
| TC-UI-003  | الـ Filter Sidebar مخفي على موبايل                            |
| TC-UI-004  | أيقونة الكارت ظاهرة على كل الصفحات                           |
| TC-UI-005  | الـ Logo بيرجع للهوم                                          |
| TC-UI-006  | الكارت بيعطي Hover State                                      |
| TC-UI-007  | زر Sign In بيعطي Hover State                                  |
| TC-UI-008  | عنوان التاب مش فاضي                                          |
| TC-UI-009  | URL غلط بيعطي 404 ومش Crash                                   |
| TC-UI-010  | الـ Checkout Form Responsive على Tablet 768×1024              |
| TC-UI-011  | صور الكاردات بنسبة ثابتة                                      |
| TC-UI-012  | رسالة الكارت الفاضي ظاهرة على موبايل                         |
| TC-UI-013  | المشروع بيشتغل صح على Safari/macOS                           |

---

## 🐛 bug_reports/ — شرح ملفات الـ BUG

> **مهم:** تيستات الـ Bug بتتحقق من الـ **Expected Behaviour الصح**.
> لو التيست **Fails** → البج لسه موجود.
> لو التيست **Passes** → البج اتصلح.

---

### `BUG_LGN_001_To_005_LoginBugTests.java` — 5 بجات
| ID          | البج                                                     | Severity |
|-------------|----------------------------------------------------------|----------|
| BUG-LGN-001 | الـ Sign In بيشتغل بدون ما تختار credentials           | Critical |
| BUG-LGN-002 | رسالة خطأ locked_user مش واضحة (مش بتقول "locked")    | Minor    |
| BUG-LGN-003 | بعد Logout، /orders لسه متاح → الـ Session مش بتتمسح  | Critical |
| BUG-LGN-004 | الـ Password "testingisfun99" مكشوف كـ plain text في DOM| Major    |
| BUG-LGN-005 | الـ Dropdowns مش عندهم aria-label → WCAG violation     | Minor    |

---

### `BUG_CRT_001_To_007_CartBugTests.java` — 7 بجات
| ID          | البج                                                        | Severity |
|-------------|-------------------------------------------------------------|----------|
| BUG-CRT-001 | الـ Badge مش بيتحدث صح لما تضيف 3 منتجات بسرعة (Race Condition) | Critical |
| BUG-CRT-002 | الـ Total مش بيتحسب تاني بعد حذف منتج (لازم Refresh)      | Critical |
| BUG-CRT-003 | زر "Remove" على الـ Listing مش بيرجع لـ "Add to cart" بعد الحذف من الكارت | Major |
| BUG-CRT-004 | Double-click على "Add to cart" بيضيف منتج مرتين           | Critical |
| BUG-CRT-005 | الكارت الفاضي مش بيعرض رسالة (صفحة فاضية)                 | Minor    |
| BUG-CRT-006 | الكارت بيتمسح بعد Refresh في Firefox 124                   | Major    |
| BUG-CRT-007 | الـ Badge مش بيرجع صفر فورًا بعد حذف كل المنتجات          | Major    |

---

### `BUG_PRD_001_To_009_ProductBugTests.java` — 9 بجات
| ID          | البج                                                        | Severity |
|-------------|-------------------------------------------------------------|----------|
| BUG-PRD-001 | فلتر Apple+Samsung بيعرض أحيانًا منتجات OnePlus (متقطع)  | Critical |
| BUG-PRD-002 | السورت "Lowest to Highest" غير ثابت للمنتجات بنفس السعر  | Major    |
| BUG-PRD-003 | الـ Checkbox مش بيتأشل تاني لما تضغط عليه مرة تانية       | Critical |
| BUG-PRD-004 | السورت بيترجع للـ Default بعد Back من صفحة التفاصيل       | Major    |
| BUG-PRD-005 | Galaxy Note 20 Ultra فيه فرق سعر بين الـ Listing والـ Detail | Major  |
| BUG-PRD-006 | iPhone 12 و12 Mini و12 Pro Max عندهم alt text = "img"     | Minor    |
| BUG-PRD-007 | Pixel 2 بيستخدم صورة placeholder (device-info.jpg)        | Minor    |
| BUG-PRD-008 | OnePlus 8 و8T و8 Pro عندهم نفس الصورة                     | Minor    |
| BUG-PRD-009 | زر "Add to Cart" مقطوع في Apple Cards على 1280×720        | Major    |

---

### `BUG_CHK_001_To_007_CheckoutBugTests.java` — 7 بجات
| ID          | البج                                                        | Severity |
|-------------|-------------------------------------------------------------|----------|
| BUG-CHK-001 | الـ Zip Code بيقبل حروف فقط زي "ABCDE" (مفيش Validation) | Critical |
| BUG-CHK-002 | صفحة التأكيد مش بتعرض Order Reference Number              | Major    |
| BUG-CHK-003 | الـ /checkout متاح لـ Unauthenticated users (Route Guard فاشل) | Critical |
| BUG-CHK-004 | Double-click على Submit بيعمل أوردر مكرر                  | Critical |
| BUG-CHK-005 | الـ State Dropdown مش Required → الـ Checkout بيكمل بدونه | Major    |
| BUG-CHK-006 | حقل الـ Address بيقبل حرف واحد "A" (مفيش min-length)     | Minor    |
| BUG-CHK-007 | صفحة الـ Checkout مفيهاش H1 heading → WCAG 1.3.1 violation | Minor   |

---

### `BUG_UI_001_To_005_UIBugTests.java` — 5 بجات
| ID         | البج                                                          | Severity |
|------------|---------------------------------------------------------------|----------|
| BUG-UI-001 | الـ Cart Badge بيطلع بره الأيقونة ويتداخل مع الـ Logo على موبايل | Major |
| BUG-UI-002 | الـ Filter Sidebar بيغطي الـ Product Grid على Tablet 768×1024 | Major  |
| BUG-UI-003 | نص زر Sign In محاذاة يسار على Firefox 124 بدل Center       | Minor    |
| BUG-UI-004 | كارت Pixel 2 بيستخدم صورة Placeholder زي BUG-PRD-007       | Minor    |
| BUG-UI-005 | صفحة التأكيد مفيهاش أي Visual Success Indicator            | Minor    |

---

## 🏗️ Architecture — Page Object Model

```
BaseTest (WebDriver lifecycle)
    │
    ├── LoginPage      → selectUsername(), selectPassword(), clickSignIn(), getErrorMessage()
    ├── ProductPage    → applyVendorFilter(), selectSort(), getProductCount(), clickProductByName()
    ├── CartPage       → getCartBadgeCount(), clickCartIcon(), removeItemByName(), getCartTotal()
    └── CheckoutPage   → fillAndSubmit(), isConfirmationPageDisplayed(), isErrorDisplayed()
```

---

## 💡 ملاحظات مهمة — Important Notes

1. **Bug Tests vs TC Tests:**
   - ملفات `TC_*` → بتتحقق إن الـ feature شغال صح
   - ملفات `BUG_*` → بتتحقق إن البج اتصلح (متوقع تـ Fail لو البج لسه موجود)

2. **Firefox Tests:**
   - TC-LGN-017، TC-CHK-021، BUG-CRT-006، BUG-UI-003 مصممين للـ Firefox
   - للتشغيل على Firefox: غيّر `ChromeDriver` لـ `FirefoxDriver` في `BaseTest.java` وأضف `webdrivermanager.firefoxdriver().setup()`

3. **Intermittent Bugs:**
   - BUG-PRD-001 بيتكرر 3 مرات لالتقاط السلوك المتقطع

4. **تشغيل بيئة محددة:**
   - الـ `Environment` في ملفات الـ TC/BUG هو Chrome 124 / Windows 11 زي ما هو في الـ Excel

---

## 📞 الفريق — Testing Team

| الاسم             | النطاق              |
|-------------------|---------------------|
| Mohamed Gamal     | Login               |
| Mohamed Abdelhamed | Product            |
| Ziad              | Cart                |
| Mohamed Ahmed     | Checkout            |
| Mohamed Mamdouh   | UI / Responsive     |
