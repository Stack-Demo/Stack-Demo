package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pages.LoginPage;
import java.time.Duration;

public class TestUtils {

    public static final String BASE_URL       = "https://bstackdemo.com";
    public static final String SIGNIN_URL     = BASE_URL + "/signin";
    public static final String VALID_PASSWORD = "testingisfun99";

    public static void loginAs(WebDriver driver, String username) {
        driver.get(SIGNIN_URL);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.urlContains("/signin"));
        // Wait for React-Select to fully render
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("username")));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("password")));
        try { Thread.sleep(1000); } catch (InterruptedException ignored) {}
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(username, VALID_PASSWORD);
        wait.until(ExpectedConditions.urlToBe(BASE_URL + "/"));
    }

    public static void setMobileViewport(WebDriver driver) {
        driver.manage().window().setSize(new Dimension(375, 667));
    }

    public static void setTabletViewport(WebDriver driver) {
        driver.manage().window().setSize(new Dimension(768, 1024));
    }

    public static void setDesktopViewport(WebDriver driver) {
        driver.manage().window().setSize(new Dimension(1280, 720));
    }

    public static void setFullHDViewport(WebDriver driver) {
        driver.manage().window().setSize(new Dimension(1920, 1080));
    }

    public static String getPageTitle(WebDriver driver) {
        return driver.getTitle();
    }

    public static String getCurrentUrl(WebDriver driver) {
        return driver.getCurrentUrl();
    }

    public static boolean imageIsLoaded(WebDriver driver, org.openqa.selenium.WebElement img) {
        return (Boolean) ((JavascriptExecutor) driver)
            .executeScript("return arguments[0].complete && arguments[0].naturalWidth > 0", img);
    }

    public static void logout(WebDriver driver) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.findElement(By.cssSelector(".user-icon, .account-icon, [class*='user']")).click();
        wait.until(ExpectedConditions.elementToBeClickable(
            By.cssSelector("[class*='logout'], [class*='signout']"))).click();
        wait.until(ExpectedConditions.urlContains("/signin"));
    }

    public static void navigateTo(WebDriver driver, String path) {
        driver.get(BASE_URL + path);
    }
}
