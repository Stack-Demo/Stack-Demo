package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;

public class LoginPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locators — React-Select components
    private final By usernameInput       = By.id("react-select-2-input");
    private final By passwordInput       = By.id("react-select-3-input");
    private final By signInButton        = By.id("login-btn");
    private final By errorMessage        = By.cssSelector(".api-error");

    // The outer container divs for the react-select dropdowns
    private final By usernameContainer   = By.cssSelector("#username .css-yk16xz-control, #username [class*='control']");
    private final By passwordContainer   = By.cssSelector("#password .css-yk16xz-control, #password [class*='control']");

    // Options inside the dropdown listbox
    private final By usernameOptions     = By.cssSelector("#react-select-2-listbox [class*='option']");
    private final By passwordOptions     = By.cssSelector("#react-select-3-listbox [class*='option']");

    // Outer containers (for simpler click targets)
    private final By usernameOuterContainer = By.id("username");
    private final By passwordOuterContainer = By.id("password");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    /**
     * Select a username from the React-Select dropdown.
     * Strategy: click the container to open dropdown, type the value to filter,
     * then click the matching option.
     */
    public void selectUsername(String username) {
        // Click the outer container to focus/open the dropdown
        WebElement container = wait.until(ExpectedConditions.elementToBeClickable(usernameOuterContainer));
        container.click();
        smallDelay();

        // Type into the hidden input to filter options
        WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(usernameInput));
        input.sendKeys(username);
        smallDelay();

        // Wait for options to appear and click the matching one
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameOptions));
        clickMatchingOption(usernameOptions, username);
    }

    /**
     * Select a password from the React-Select dropdown.
     */
    public void selectPassword(String password) {
        WebElement container = wait.until(ExpectedConditions.elementToBeClickable(passwordOuterContainer));
        container.click();
        smallDelay();

        WebElement input = wait.until(ExpectedConditions.presenceOfElementLocated(passwordInput));
        input.sendKeys(password);
        smallDelay();

        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordOptions));
        clickMatchingOption(passwordOptions, password);
    }

    public void clickSignIn() {
        wait.until(ExpectedConditions.elementToBeClickable(signInButton)).click();
    }

    public void login(String username, String password) {
        selectUsername(username);
        smallDelay();
        selectPassword(password);
        smallDelay();
        clickSignIn();
    }

    public String getErrorMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(errorMessage)).getText();
    }

    public boolean isErrorDisplayed() {
        try {
            return driver.findElement(errorMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public int getUsernameOptionsCount() {
        WebElement container = wait.until(ExpectedConditions.elementToBeClickable(usernameOuterContainer));
        container.click();
        smallDelay();
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameOptions));
        int count = driver.findElements(usernameOptions).size();
        // Close dropdown by pressing Escape
        driver.findElement(usernameInput).sendKeys(Keys.ESCAPE);
        smallDelay();
        return count;
    }

    public boolean usernameOptionExists(String name) {
        WebElement container = wait.until(ExpectedConditions.elementToBeClickable(usernameOuterContainer));
        container.click();
        smallDelay();
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameOptions));
        boolean exists = driver.findElements(usernameOptions).stream()
            .anyMatch(el -> el.getText().trim().equalsIgnoreCase(name));
        driver.findElement(usernameInput).sendKeys(Keys.ESCAPE);
        smallDelay();
        return exists;
    }

    public boolean passwordOptionExists(String pwd) {
        WebElement container = wait.until(ExpectedConditions.elementToBeClickable(passwordOuterContainer));
        container.click();
        smallDelay();
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordOptions));
        boolean exists = driver.findElements(passwordOptions).stream()
            .anyMatch(el -> el.getText().trim().equalsIgnoreCase(pwd));
        driver.findElement(passwordInput).sendKeys(Keys.ESCAPE);
        smallDelay();
        return exists;
    }

    public boolean isSignInButtonEnabled() {
        return driver.findElement(signInButton).isEnabled();
    }

    // ──────────── Helper Methods ────────────

    /**
     * Click the first option whose text matches (case-insensitive, trimmed).
     * Falls back to clicking the first option if no exact match found.
     */
    private void clickMatchingOption(By optionsLocator, String value) {
        List<WebElement> options = driver.findElements(optionsLocator);
        for (WebElement option : options) {
            if (option.getText().trim().equalsIgnoreCase(value)) {
                option.click();
                return;
            }
        }
        // If typing filtered to a single option, click it
        if (!options.isEmpty()) {
            options.get(0).click();
        }
    }

    /**
     * Small delay to allow React-Select to process events and render.
     */
    private void smallDelay() {
        try {
            Thread.sleep(500);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }
}
