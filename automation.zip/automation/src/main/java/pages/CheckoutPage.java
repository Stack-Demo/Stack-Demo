package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

public class CheckoutPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Form locators
    private final By firstNameField     = By.id("firstNameInput");
    private final By lastNameField      = By.id("lastNameInput");
    private final By addressField       = By.id("addressLine1Input");
    private final By stateDropdown      = By.id("provinceInput");
    private final By zipField           = By.id("postCodeInput");
    private final By submitButton       = By.id("checkout-shipping-continue");

    // Result / validation locators
    private final By errorMessages      = By.cssSelector(".checkout-error, .field-error, [class*='error']");
    private final By confirmationHeader = By.cssSelector(".order-confirmation, .confirmation-heading, [class*='confirm']");
    private final By orderSummaryItems  = By.cssSelector(".order-summary .item");
    private final By orderTotal         = By.cssSelector(".order-summary .total");
    private final By h1Heading          = By.tagName("h1");
    private final By stateOptions       = By.cssSelector("#provinceInput option");

    public CheckoutPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void enterFirstName(String firstName) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField));
        field.clear();
        field.sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameField));
        field.clear();
        field.sendKeys(lastName);
    }

    public void enterAddress(String address) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(addressField));
        field.clear();
        field.sendKeys(address);
    }

    public void selectState(String state) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(stateDropdown));
        new Select(dropdown).selectByVisibleText(state);
    }

    public void enterZip(String zip) {
        WebElement field = wait.until(ExpectedConditions.visibilityOfElementLocated(zipField));
        field.clear();
        field.sendKeys(zip);
    }

    public void clickSubmit() {
        wait.until(ExpectedConditions.elementToBeClickable(submitButton)).click();
    }

    public void fillAndSubmit(String firstName, String lastName, String address, String state, String zip) {
        enterFirstName(firstName);
        enterLastName(lastName);
        enterAddress(address);
        if (state != null && !state.isEmpty()) selectState(state);
        enterZip(zip);
        clickSubmit();
    }

    public boolean isConfirmationPageDisplayed() {
        try {
            wait.until(ExpectedConditions.visibilityOfElementLocated(confirmationHeader));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isErrorDisplayed() {
        try {
            List<WebElement> errors = driver.findElements(errorMessages);
            return errors.stream().anyMatch(WebElement::isDisplayed);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isCheckoutFormDisplayed() {
        try {
            return driver.findElement(firstNameField).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isH1Present() {
        try {
            return driver.findElement(h1Heading).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public List<String> getStateOptions() {
        WebElement dropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(stateDropdown));
        return new Select(dropdown).getOptions().stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public String getConfirmationText() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(confirmationHeader)).getText();
    }

    public boolean confirmationContainsProduct(String productName) {
        try {
            String pageSource = driver.getPageSource();
            return pageSource.contains(productName);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isOrderNumberPresent() {
        String src = driver.getPageSource().toLowerCase();
        return src.contains("order #") || src.contains("order id") || src.contains("order number")
            || src.matches(".*ord-\\d+.*") || src.matches(".*#\\d{4,}.*");
    }
}
