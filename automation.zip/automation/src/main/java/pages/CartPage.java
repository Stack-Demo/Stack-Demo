package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

public class CartPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private final By cartIcon           = By.cssSelector(".cart-icon");
    private final By cartBadge          = By.cssSelector(".cart-icon .badge");
    private final By cartItems          = By.cssSelector(".cart-list-item");
    private final By cartItemNames      = By.cssSelector(".cart-list-item .title");
    private final By cartItemPrices     = By.cssSelector(".cart-list-item .price");
    private final By removeButtons      = By.cssSelector(".cart-list-item .remove-item");
    private final By cartTotal          = By.cssSelector(".sub-price__val");
    private final By checkoutButton     = By.cssSelector(".buy-btn");
    private final By emptyCartMessage   = By.cssSelector(".cart-empty-message, .empty-cart");
    private final By cartItemThumbnails = By.cssSelector(".cart-list-item img");

    public CartPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void clickCartIcon() {
        wait.until(ExpectedConditions.elementToBeClickable(cartIcon)).click();
        wait.until(ExpectedConditions.urlContains("/cart"));
    }

    public int getCartBadgeCount() {
        try {
            String text = driver.findElement(cartBadge).getText().trim();
            return text.isEmpty() ? 0 : Integer.parseInt(text);
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean isBadgeVisible() {
        try {
            return driver.findElement(cartBadge).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public int getCartItemCount() {
        return driver.findElements(cartItems).size();
    }

    public List<String> getCartItemNames() {
        return driver.findElements(cartItemNames).stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public double getCartTotal() {
        String text = wait.until(ExpectedConditions.visibilityOfElementLocated(cartTotal))
            .getText().replace("$", "").replace(",", "").trim();
        return Double.parseDouble(text);
    }

    public void removeItemByName(String name) {
        List<WebElement> items = driver.findElements(cartItems);
        for (WebElement item : items) {
            String title = item.findElement(By.cssSelector(".title")).getText();
            if (title.equalsIgnoreCase(name)) {
                item.findElement(By.cssSelector(".remove-item")).click();
                try { Thread.sleep(500); } catch (InterruptedException ignored) {}
                return;
            }
        }
    }

    public void clickCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
        wait.until(ExpectedConditions.urlContains("/checkout"));
    }

    public boolean isEmptyCartMessageVisible() {
        try {
            return driver.findElement(emptyCartMessage).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isProductInCart(String productName) {
        return getCartItemNames().stream()
            .anyMatch(name -> name.equalsIgnoreCase(productName));
    }

    public String getThumbnailSrcByProductName(String name) {
        List<WebElement> items = driver.findElements(cartItems);
        for (WebElement item : items) {
            String title = item.findElement(By.cssSelector(".title")).getText();
            if (title.equalsIgnoreCase(name)) {
                return item.findElement(By.cssSelector("img")).getAttribute("src");
            }
        }
        return "";
    }
}
