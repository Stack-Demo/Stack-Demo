package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
import java.util.stream.Collectors;

public class ProductPage {

    private WebDriver driver;
    private WebDriverWait wait;

    // Locators
    private final By productCards       = By.cssSelector(".shelf-item");
    private final By productNames       = By.cssSelector(".shelf-item__title");
    private final By productPrices      = By.cssSelector(".shelf-item__price .val b");
    private final By productImages      = By.cssSelector(".shelf-item__thumb img");
    private final By addToCartButtons   = By.cssSelector(".shelf-item__buy-btn");
    private final By vendorCheckboxes   = By.cssSelector(".checkmark");
    private final By sortDropdown       = By.cssSelector(".sort select");
    private final By filterLabels       = By.cssSelector(".filters-available-size");
    private final By heartIcons         = By.cssSelector(".shelf-item__heart");

    public ProductPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public int getProductCount() {
        wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(productCards));
        return driver.findElements(productCards).size();
    }

    public void applyVendorFilter(String vendor) {
        List<WebElement> labels = driver.findElements(filterLabels);
        labels.stream()
            .filter(el -> el.getText().equalsIgnoreCase(vendor))
            .findFirst()
            .ifPresent(WebElement::click);
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
    }

    public void selectSort(String sortOption) {
        WebElement dropdown = wait.until(ExpectedConditions.elementToBeClickable(sortDropdown));
        new Select(dropdown).selectByVisibleText(sortOption);
        try { Thread.sleep(800); } catch (InterruptedException ignored) {}
    }

    public List<String> getProductNamesList() {
        return driver.findElements(productNames).stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public List<Double> getProductPricesList() {
        return driver.findElements(productPrices).stream()
            .map(el -> Double.parseDouble(el.getText().replace(",", "")))
            .collect(Collectors.toList());
    }

    public void clickProductByName(String name) {
        driver.findElements(productNames).stream()
            .filter(el -> el.getText().equalsIgnoreCase(name))
            .findFirst()
            .ifPresent(WebElement::click);
        wait.until(ExpectedConditions.urlContains("/product/"));
    }

    public void addToCartByName(String name) {
        List<WebElement> cards = driver.findElements(productCards);
        for (WebElement card : cards) {
            String title = card.findElement(By.cssSelector(".shelf-item__title")).getText();
            if (title.equalsIgnoreCase(name)) {
                card.findElement(By.cssSelector(".shelf-item__buy-btn")).click();
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
                return;
            }
        }
    }

    public String getButtonLabelByProductName(String name) {
        List<WebElement> cards = driver.findElements(productCards);
        for (WebElement card : cards) {
            String title = card.findElement(By.cssSelector(".shelf-item__title")).getText();
            if (title.equalsIgnoreCase(name)) {
                return card.findElement(By.cssSelector(".shelf-item__buy-btn")).getText();
            }
        }
        return "";
    }

    public boolean isVendorCheckboxChecked(String vendor) {
        List<WebElement> labels = driver.findElements(filterLabels);
        for (WebElement label : labels) {
            if (label.getText().equalsIgnoreCase(vendor)) {
                WebElement parent = label.findElement(By.xpath("./.."));
                WebElement cb = parent.findElement(By.cssSelector("input[type='checkbox']"));
                return cb.isSelected();
            }
        }
        return false;
    }

    public boolean areProductImagesLoaded() {
        List<WebElement> imgs = driver.findElements(productImages);
        for (WebElement img : imgs) {
            Object result = ((JavascriptExecutor) driver)
                .executeScript("return arguments[0].complete && arguments[0].naturalWidth > 0", img);
            if (!(Boolean) result) return false;
        }
        return true;
    }

    public boolean areProductImagesBroken() {
        List<WebElement> imgs = driver.findElements(productImages);
        for (WebElement img : imgs) {
            Object result = ((JavascriptExecutor) driver)
                .executeScript("return arguments[0].complete && arguments[0].naturalWidth > 0", img);
            if ((Boolean) result) return false;
        }
        return true;
    }

    public boolean isFilterPanelVisible() {
        try {
            return driver.findElement(By.cssSelector(".filters")).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    public List<String> getVendorFilterNames() {
        return driver.findElements(filterLabels).stream()
            .map(WebElement::getText)
            .collect(Collectors.toList());
    }

    public boolean hasFavouriteIcons() {
        return !driver.findElements(heartIcons).isEmpty();
    }

    public String getProductPriceByName(String name) {
        List<WebElement> cards = driver.findElements(productCards);
        for (WebElement card : cards) {
            String title = card.findElement(By.cssSelector(".shelf-item__title")).getText();
            if (title.equalsIgnoreCase(name)) {
                return card.findElement(By.cssSelector(".shelf-item__price .val b")).getText();
            }
        }
        return "";
    }
}
